export interface Compte {
  idCompte:String;
  idUser:String;
  idTontine:String;
  solde : String;
  etat: String;
  typeApprovisionnement:String;

}
