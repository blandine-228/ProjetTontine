export interface Operation {
  idOperation: String;
  idTontine: String;
  dateOperation: String;
  montant: String;
  etat: String;
}
