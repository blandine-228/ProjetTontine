export interface Situation{
    idSituation:String;
    idUser:String;
    solde:number;  
    dateMouvement:String;    
    telephone:number;
    typeOperation:String;  
    moyenOperation:String;
    codeTransaction:String;
    etat:number,
  }
  