export interface  Tontine{
  idTontine:String;
  idPeriode:String;
  idUser:String;
  nomTontine:String;
  solde:number;
  dateDebut:String;
  nbreMaxAdherant:number;
  montantCotisation:number;
  logo:String,
  nbreMinAdherant:number,
}
