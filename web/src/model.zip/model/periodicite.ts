export interface Periodicite{
  idPeriode:String;
  libellePeriode:String;
  nombreJour:number
}
