export interface Utilisateur{
  idUser : String;
  idProfil:String;
  nomUser:String;
  prenomUser:String;
  password:String;
  numTel:String;
  email:String;
  username:String;
  imageProfil:String;
  solde:number;
}
