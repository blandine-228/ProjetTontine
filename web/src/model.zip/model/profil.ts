export interface Profil {
  idProfil: String;
  libelleProfil: String;
}
