export interface Tirage{
  idTirage:String;
  idTontine:String;
  idCompte:String;
  numOrdre:number;
  dateTirage:String;

}
