import { NgModule,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { FormsModule,ReactiveFormsModule  } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from "@angular/common";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { FooterComponent } from './template/footer/footer.component';
import { MenuComponent } from './template/menu/menu.component';
import { HeaderComponent } from './template/header/header.component';
import { TopbarComponent } from './template/topbar/topbar.component';
import { SidebarComponent } from './template/sidebar/sidebar.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TontineComponent } from './tontine/tontine.component';
import { HttpClientModule } from '@angular/common/http';
import { PeriodiciteComponent } from './periodicite/periodicite.component';
import { ProfilComponent } from './profil/profil.component';
import { UtilisateurComponent } from './utilisateur/utilisateur.component';
import { CompteComponent } from './compte/compte.component';
import { OperationComponent } from './operation/operation.component';
import { TirageComponent } from './tirage/tirage.component';
import { CotisationComponent } from './cotisation/cotisation.component';
import { RetraitComponent } from './retrait/retrait.component';
import { MoncompteComponent } from './moncompte/moncompte.component';
import { LogedmenuComponent } from './logedmenu/logedmenu.component';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { ErrorComponent } from './error/error.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    FooterComponent,
    MenuComponent,
    HeaderComponent,
    TopbarComponent,
    SidebarComponent,
    ProfilComponent,
    DashboardComponent,
    TontineComponent,
    PeriodiciteComponent,
    UtilisateurComponent,
    CompteComponent,
    OperationComponent,
    TirageComponent,
    CotisationComponent,
    RetraitComponent,
    MoncompteComponent,
    LogedmenuComponent,
    RegisterComponent,
    ErrorComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule

  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})

export class AppModule { }
