export enum Utils{
   BASE_URL = "http://localhost:3000/api/",
   LOGIN_URI = "login"
}
