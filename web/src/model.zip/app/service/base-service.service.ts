import { WSResponse, WSResponseError } from './../../model/WSResponse';
import { Utils } from './utils';
import { Profil } from './../../model/profil';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class BaseServiceService {

  private httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json','responseType': 'text'})
  };
   private httpToken= {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'responseType': 'text',
      'authorization':"Bearer "+localStorage.getItem("userToken")
  })};
  constructor(private http:HttpClient) {
    if(window.localStorage && localStorage.getItem("userToken")!=null){
      console.log("token : "+localStorage.getItem("userToken"));
      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'responseType': 'text',
          'authorization':"Bearer "+localStorage.getItem("userToken")
      })};
      console.log(this.httpOptions);
    };
  }


  get(uri:string){
    console.log(this.httpToken);
    
    return this.http.get (Utils.BASE_URL+uri,this.httpToken);
  }
  getWithHearder(uri:string,header:HttpHeaders){
    let httpTokenn= {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'responseType': 'text',
        'authorization':"Bearer "+localStorage.getItem("userToken")
    })};
    return this.http.get (Utils.BASE_URL+uri,httpTokenn );
  }
  post(uri:string,body:any){
    console.log("token : "+localStorage.getItem("userToken"));
    return this.http.post(Utils.BASE_URL+uri,body,this.httpOptions);

  }
  patch(uri:string,body:any){
    console.log("token : "+localStorage.getItem("userToken"));
    return this.http.patch(Utils.BASE_URL+uri,body,this.httpOptions);

  }
  delete(uri:string,body:any){
    console.log("token : "+localStorage.getItem("userToken"));
    return this.http.delete(Utils.BASE_URL+uri,body);

  }
  authService(username:String,password:String){
    let head = {
      headers: new HttpHeaders({ 'Authorization': 'Basic '+btoa(username+":"+password)})
    };
    return this.http.post(Utils.BASE_URL+Utils.LOGIN_URI,{});
  }
  getActiveUser(){
    if(window.localStorage && localStorage.getItem('userInfo')!=null){
      let userstring = localStorage.getItem('userInfo')!=null?localStorage.getItem('userInfo'):"";
        return JSON.parse(userstring!=null?userstring:"");
    }else{
      return null;
    }
  }

}
