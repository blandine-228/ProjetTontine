import { Component, OnInit } from '@angular/core';
import { Operation } from './../../model/operation';
import { BaseServiceService } from './../service/base-service.service';

@Component({
  selector: 'app-operation',
  templateUrl: './operation.component.html',
  styleUrls: ['./operation.component.css']
})
export class OperationComponent implements OnInit {
  page = 'form';
  public ListOperation : Array<Operation> = [];
  selectedOperation : Operation = {
    idOperation:'',
    idTontine:'',
    dateOperation:'',
    montant: '',
    etat: ''
  };


  constructor(private basews:BaseServiceService) {}

  ngOnInit(): void {
  }

}
