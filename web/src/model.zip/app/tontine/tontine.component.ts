import { Compte } from './../../model/compte';
import { Periodicite } from './../../model/periodicite';
import { BaseServiceService } from './../service/base-service.service';
import { Tontine } from './../../model/tontine';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tontine',
  templateUrl: './tontine.component.html',
  styleUrls: ['./tontine.component.css'],
})
export class TontineComponent implements OnInit {
  page = 'liste';
  user: any;
  public listeTontine: Array<Tontine> = [];
  public listeCompte: Array<Compte> = [];
  base64textString = '';
  selectedTontine: Tontine = {
    idTontine: '',
    idPeriode: '',
    idUser: '',
    nomTontine: '',
    solde: 0,
    dateDebut: '',
    nbreMaxAdherant: 0,
    montantCotisation: 0,
    logo: '',
    nbreMinAdherant: 0,
  };
  constructor(private basews: BaseServiceService) {}

  ngOnInit(): void {
    this.user = this.basews.getActiveUser();
    console.log(this.user);
    this.chargerLesInformation();
  }
  public listPeriodicite: Array<Periodicite> = [];
  chargerLesInformation() {
    this.listerPeriode();
    this.listerCompte();
    this.selectedTontine = {
      idTontine: '',
      idPeriode: '',
      idUser: '',
      nomTontine: '',
      solde: 0,
      dateDebut: '',
      nbreMaxAdherant: 0,
      montantCotisation: 0,
      logo: '',
      nbreMinAdherant: 0,
    };
  }
  listerPeriode() {
    this.basews.get('periodicite').subscribe(
      (data) => {
        this.listPeriodicite = (data as any).data;
        console.log(this.listPeriodicite);
      },
      (error) => {
        console.log(error);
      }
    );
  }
  listerCompte() {
    this.basews.get('compte').subscribe(
      (data) => {
        if((data as any).success=="1"){
          this.listeCompte = (data as any).data;
        }        
        console.log(data);
        this.listerTontine();
      },
      (error) => {
        console.log(error);
      }
    );
  }
  listerTontine() {
    this.basews.get('tontine').subscribe(
      (data) => {
        console.log(data);
        this.listeTontine = (data as any).data;
        console.log(this.listeTontine);
        console.log(this.listeTontine.length);
      },
      (error) => {
        console.log(error);
      }
    );
    this.basews.get('tontine/user/').subscribe(
      (data) => {
        //this.listeTontine = (data as any).data;
        console.log(data as any);
      },
      (error) => {
        console.log(error);
      }
    );
  }
  estMenbreDeTontine(idTontine: any): boolean {
    console.log(this.listeCompte);
   /*
    for (let i = 0; i < this.listeCompte.length; i++) {
      if (this.listeCompte[i].idTontine == idTontine) {
        console.log("this.listeCompte[i].idTontine");
        return true;
      }
    }*/
     this.basews.get("compte/find/"+idTontine).subscribe(
      (data)=>{
        console.log(data)
      },
      (error)=>{

      });
    return false;
  }
  handleFileSelect(evt: any) {
    var files = evt.target.files;
    var file = files[0];

    if (files && file) {
      var reader = new FileReader();

      reader.onload = this._handleReaderLoaded.bind(this);

      reader.readAsBinaryString(file);
    }
  }

  _handleReaderLoaded(readerEvt: any) {
    var binaryString = readerEvt.target.result;
    this.base64textString = btoa(binaryString);
    this.selectedTontine.logo = "data:image/jpg;base64,"+btoa(binaryString);
    //console.log(btoa(binaryString));
  }
  ajouterForm() {
    this.page = 'form';
  }
  listerForm() {
    this.page = 'liste';
    this.listerTontine();
  }
  valider() {
    console.log(this.selectedTontine);
    this.basews.post('tontine', this.selectedTontine).subscribe(
      (data) => {
        console.log(data);
        window.location.reload();        
        this.listerForm();
      },
      (error) => {
        console.log(error);
      }
    );
  }
  adhererTontine(idTontine:any) {
    console.log(idTontine);
    this.basews.get('compte/add/' + idTontine).subscribe(
      (data) => {
        console.log(data);
        window.location.reload();
      },
      (error) => {
        console.log(error);
      }
    );
  }
}
