import { WSResponse, WSResponseError } from './../../model/WSResponse';
import { Profil } from './../../model/profil';
import { BaseServiceService } from './../service/base-service.service';
import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
@Component({
  selector: 'app-profil',
  templateUrl: './profil.component.html',
  styleUrls: ['./profil.component.css'],
})
export class ProfilComponent implements OnInit {
  public listProfil:Array<Profil>=[];
  public selectedProfil: Profil ={idProfil:"",libelleProfil:""};
  constructor(private basews: BaseServiceService) {}

  ngOnInit(): void {
    this.chargerProfil();
  }

  chargerProfil(){
    this.listProfil=[];
    this.basews.get('profil').subscribe(
      (data) => {
        console.log(data);
        if((data as any).success==1){
          this.listProfil = (data as any).data;
          console.log(this.listProfil);
          console.log
        }

      },
      (error) => {
        console.log(error);
      }
    );
  }

  initSelectProfil(item:Profil){
    this.selectedProfil=item;
    console.log(this.selectedProfil);
  }
  resetSelectedProfil(){
    this.selectedProfil ={idProfil:"",libelleProfil:""};
  }
  valider(){
    if(this.selectedProfil.libelleProfil!=""){
       if(this.selectedProfil.idProfil==""){
          this.createProfil();
       }else{
         this.updateProfil();
       }
    }

  }
  updateProfil() {
    this.basews.patch('profil', this.selectedProfil).subscribe(
      (data) => {
        console.log(data);
      },
      (error) => {
        console.error;
      }
    );
  }
  createProfil() {
    this.basews.post('profil', this.selectedProfil).subscribe(
      (data) => {
        console.log(data);
        this.chargerProfil();
      },
      (error) => {
        console.error;
      }
    );
  }

  deleteProfil(item:Profil) {
    console.log(item);
    this.basews.delete('profil', item).subscribe(
      (data) => {
        console.log(data);
        this.chargerProfil();
      },
      (error) => {
        console.error;
      }
    );
  }
}


