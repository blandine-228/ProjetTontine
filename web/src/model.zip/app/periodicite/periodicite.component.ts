import { Periodicite } from './../../model/periodicite';
import { Component, OnInit } from '@angular/core';
import { BaseServiceService } from './../service/base-service.service';
@Component({
  selector: 'app-periodicite',
  templateUrl: './periodicite.component.html',
  styleUrls: ['./periodicite.component.css'],
})
export class PeriodiciteComponent implements OnInit {
  public listPeriodicite: Array<Periodicite> = [];
  selectedPeriode: Periodicite = {
    idPeriode: '',
    libellePeriode: '',
    nombreJour: 0,
  };

  constructor(private basews: BaseServiceService) {}

  ngOnInit(): void {
    this.lister();
  }

  valider() {
    if (
      this.selectedPeriode.libellePeriode != '' &&
      this.selectedPeriode.nombreJour > 0
    ) {
      this.basews.post('periodicite', this.selectedPeriode).subscribe(
        (data) => {
          console.log(data), this.lister();
        },
        (error) => {
          console.log(error);
        }
      );
    }
  }
  lister() {
    this.basews.get('periodicite').subscribe(
      (data) => {
        console.log(data), (this.listPeriodicite = (data as any).data);
      },
      (error) => {
        console.log(error);
      }
    );
  }
  create() {
    this.basews.post('periodicite', this.selectedPeriode).subscribe(
      (data) => {
        console.log(data), (this.listPeriodicite = (data as any).data);
      },
      (error) => {
        console.log(error);
      }
    );
  }
  //a faire plutart
  delete(item:Periodicite) {
    console.log(item);
  }
  update() {}

  resetSelectedProfil() {
    this.selectedPeriode = {
      idPeriode: '',
      libellePeriode: '',
      nombreJour: 0,
    };
  }
  initSelect(item: Periodicite) {
    this.selectedPeriode = item;
  }
}
