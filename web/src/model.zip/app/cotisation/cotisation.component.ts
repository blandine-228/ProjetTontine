import { Component, OnInit } from '@angular/core';
import { BaseServiceService } from './../service/base-service.service';


@Component({
  selector: 'app-cotisation',
  templateUrl: './cotisation.component.html',
  styleUrls: ['./cotisation.component.css']
})
export class CotisationComponent implements OnInit {
  page = 'form';

  constructor(private basews:BaseServiceService) {}


  ngOnInit(): void {
  }

}
