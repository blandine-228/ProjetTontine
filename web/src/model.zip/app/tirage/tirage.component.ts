import { Component, OnInit } from '@angular/core';
import { Tontine } from 'src/model/tontine';
import { Tirage } from './../../model/tirage';
import { BaseServiceService } from './../service/base-service.service';


@Component({
  selector: 'app-tirage',
  templateUrl: './tirage.component.html',
  styleUrls: ['./tirage.component.css']
})
export class TirageComponent implements OnInit {
  page = 'form';
  public listetontine:Array<Tontine>=[];
  public idSelectedTontine:String="";
  public ListTirage : Array<Tirage> = [];
  selectedTirage : Tirage = {
    idTirage:'',
    idTontine:'',
    idCompte:'',
    numOrdre: 1,
    dateTirage:''

  };

  constructor(private basews:BaseServiceService) {}

  ngOnInit(): void {
  }

}
