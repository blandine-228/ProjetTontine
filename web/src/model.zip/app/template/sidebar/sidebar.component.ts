import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'],
})
export class SidebarComponent implements OnInit {
  username:any;

  constructor() {}

  ngOnInit(): void {
    if(window.localStorage&& localStorage.getItem('username'))
    this.username = localStorage.getItem('username');
    console.log(this.username)
  }
}
