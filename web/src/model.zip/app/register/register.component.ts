import { BaseServiceService } from './../service/base-service.service';
import { Utilisateur } from './../../model/utilisateur';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
user:Utilisateur={
  idUser :"",
  idProfil:"",
  nomUser:"",
  prenomUser:"",
  password:"",
  numTel:"",
  email:"",
  username:"",
  imageProfil:"",
  solde:0

}
label=["nom",'prenom'];
userForm = new FormGroup({
	nom: new FormControl('', Validators.maxLength(3)),
	prenom: new FormControl('', Validators.maxLength(3)),
	password: new FormControl('', Validators.maxLength(6)),
	confpass: new FormControl('', [Validators.minLength(6)]),
	tel: new FormControl('',[Validators.minLength(8)]),
	username: new FormControl('',[Validators.minLength(6)]),
	email: new FormControl('',[Validators.email])
 });
  constructor(private basews:BaseServiceService) { }

  ngOnInit(): void {
  }
  onFormSubmit(){
    console.log(this.userForm);
    if(this.userForm!=null){
       this.user={
        idUser : "",
        idProfil:"1",
        nomUser:this.userForm.get("nom")?.value,
        prenomUser:this.userForm.get("prenom")?.value,
        password:this.userForm.get("password")?.value,
        numTel:this.userForm.get("tel")?.value,
        email:this.userForm.get("email")?.value,
        username:this.userForm.get("username")?.value,
        imageProfil:"",
        solde:0,
      
    }
    console.log(this.user);
    this.basews.post("users",this.user).subscribe(
      data=>{
        console.log(data);
        let resultat= (data as any).data.affectedRows;
        if(resultat==1){
          window.location.href="login";
        }
      },
      error=>{
        console.log(error);
      }

    );
    }
   
  }
}
