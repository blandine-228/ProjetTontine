import { Component, OnInit } from '@angular/core';
import { BaseServiceService } from './../service/base-service.service';
import { Situation } from 'src/model/situation';
@Component({
  selector: 'app-moncompte',
  templateUrl: './moncompte.component.html',
  styleUrls: ['./moncompte.component.css']
})
export class MoncompteComponent implements OnInit {

  constructor(private basews: BaseServiceService) {}

  solde = 0;
  transation = {
    typeOpetion:"",
    montant:0,
    telephone:0
  }
  situation :Situation={
    idSituation:"",
    idUser:"",
    solde:0,
    typeOperation:"",    
    dateMouvement:"",    
    telephone:0,
    moyenOperation:"",
    codeTransaction:"",
    etat:0,
  }
  ngOnInit(): void {
    this.getUsersolde();
    this.getAllRetrait();
    this.getAllCotisation();
    
  }
  getUsersolde(){
    this.basews.get("users/solde/").subscribe(
      (data)=>{
        console.log(data);
        this.solde = (data as any).data.solde;
      },
      (error)=>{

      }
    )
  }
  getAllRetrait(){
    this.basews.get("operation/byref/R").subscribe(
      data=>{
        console.log(data);
      },
      error=>{
        console.log(error);
      })
  }
  getAllCotisation(){
    this.basews.get("operation/byref/C").subscribe(
      data=>{
        console.log(data);
      },
      error=>{
        console.log(error);
      })
  }
  faireTransation(){
    console.log(this.situation);
    this.basews.post("operation/situation/",this.situation).subscribe(
      data=>{
        console.log(data);
      },
      error=>{
        console.log(error);
      }
    );
  }
}
