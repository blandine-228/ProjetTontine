import { Tontine } from 'src/model/tontine';
import { TontineDetail } from 'src/model/TontineDetail';
import { Component, OnInit } from '@angular/core';
import { BaseServiceService } from './../service/base-service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  listeTontine:Array<Tontine>=[];
  listeAll:Array<TontineDetail>=[];
  constructor(private basews:BaseServiceService) { }

  ngOnInit(): void {
    console.log(localStorage.getItem('userToken'));
    this.listerTontine();
    this.listerAllTontine();
  }

  listerTontine() {
    this.basews.get('tontine').subscribe(
      (data) => {
        console.log(data);
         this.listeTontine = (data as any).data;
         console.log(this.listeTontine);
      },
      (error) => {
        console.log(error);
      }
    );
  }
  listerAllTontine() {
    this.basews.get('tontine/all/').subscribe(
      (data) => {
        console.log(data);
         this.listeAll = (data as any).data;
         console.log(data);
      },
      (error) => {
        console.log(error);
      }
    );
  }

}