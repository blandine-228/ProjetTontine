import { Component, OnInit } from '@angular/core';
import { BaseServiceService } from './../service/base-service.service';
import { Utilisateur } from './../../model/utilisateur';

@Component({
  selector: 'app-utilisateur',
  templateUrl: './utilisateur.component.html',
  styleUrls: ['./utilisateur.component.css']
})
export class UtilisateurComponent implements OnInit {
  page = 'form';
  public listUtilisateur:Array<Utilisateur>=[];
  base64textString="";

  selectedUtilisateur: Utilisateur = {
    idUser: '',
    idProfil: '',
    nomUser : '',
    prenomUser : '',
    password : '',
    numTel : '',
    email : '',
    username : '',
    imageProfil: '',
    solde: 0,
   
  };

  constructor(private basews:BaseServiceService) { }

  ngOnInit(): void {
    this.chargerUtilisateur();
  }

  chargerUtilisateur(){
    this.listUtilisateur=[];
    this.basews.get('utilisateur').subscribe(
      (data) => {
        console.log(data);
        if((data as any).success == 1){
          this.listUtilisateur = (data as any).data;
          console.log(this.listUtilisateur);
          console.log
        }
      },
      (error)=>{
        console.log(error);
      }
    );
    
  }

  initselectUtilisateur(item:Utilisateur){
    this.selectedUtilisateur = item;
    console.log(this.selectedUtilisateur);
  }

  resetselectedUtilisateur(){
    this.selectedUtilisateur = {
      idUser: '',
      idProfil: '',
      nomUser : '',
      prenomUser : '',
      password : '',
      numTel : '',
      email : '',
      username : '',
      imageProfil: '',
      solde: 0,
    }
  }

  handleFileSelect(evt:any) {
    var files = evt.target.files;
    var file = files[0];

    if (files && file) {
      var reader = new FileReader();

      reader.onload = this._handleReaderLoaded.bind(this);

      reader.readAsBinaryString(file);
    }
  }

  _handleReaderLoaded(readerEvt:any) {
    var binaryString = readerEvt.target.result;
    this.base64textString = btoa(binaryString);
    this.selectedUtilisateur.imageProfil = btoa(binaryString);
    //console.log(btoa(binaryString));
  }
  ajouterForm(){
    this.page='form';
  }
  listerForm(){
    this.page='liste';
  }
  valider(){
    console.log(this.selectedUtilisateur);
  }

}
