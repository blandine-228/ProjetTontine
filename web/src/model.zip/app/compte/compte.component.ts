import { Component, OnInit } from '@angular/core';
import { Compte } from './../../model/compte';
import { BaseServiceService } from './../service/base-service.service';

@Component({
  selector: 'app-compte',
  templateUrl: './compte.component.html',
  styleUrls: ['./compte.component.css']
})
export class CompteComponent implements OnInit {
  page = 'form';
  public listCompte: Array<Compte> = [];
  selectedCompte: Compte = {
      idCompte:'',
      idUser:'',
      idTontine:'',
      solde : '',
      etat: '',
      typeApprovisionnement:''
  };
  constructor(private basews:BaseServiceService) {}

  ngOnInit(): void {
  }

}
