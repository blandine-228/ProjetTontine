import { BaseServiceService } from './../service/base-service.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginForm = new FormGroup({
    password: new FormControl('', Validators.maxLength(6)),
    username: new FormControl('', Validators.minLength(6)),
  });

  constructor(private basews: BaseServiceService) {}

  ngOnInit(): void {
    window.localStorage.clear();
  }
  onFormSubmit() {
    console.log(this.loginForm);
    if (this.loginForm != null) {
      let user = {
        username: this.loginForm.get('username')?.value,
        password: this.loginForm.get('password')?.value,
      };

      this.basews.post('users/login', user).subscribe(
        (data) => {
          console.log(data);
          console.log((data as any).token);
          let resultat = (data as any).success;
          if (resultat == 1) {
            localStorage.setItem('username', user.username);
            localStorage.setItem('userToken', (data as any).token);
            console.log(localStorage.getItem('userToken'));
            this.saveUserInsession((data as any).token);
          }
        },
        (error) => {
          console.log(error);
        }
      );
    }
  }
  saveUserInsession(token:any) {

    this.basews.getWithHearder('users/infos',token).subscribe(
      (data) => {
        console.log(data);

          if((data as any).success==1){
            localStorage.setItem('userInfo', JSON.stringify((data as any).data));
          window.location.href = '/home';
          }


        //
      },
      (error) => {
        console.log(error);
      }
    );
  }
}
