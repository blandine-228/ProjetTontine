import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  //templateUrl: './app.hometemplate.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'tontineAngular';
  isloged ="false";
  public tab=[1,2,3,3];
  
}
