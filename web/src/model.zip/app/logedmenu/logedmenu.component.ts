import { Component, OnInit } from '@angular/core';

import { BaseServiceService } from './../service/base-service.service';
declare function jsfix():any;
@Component({
  selector: 'app-logedmenu',
  templateUrl: './logedmenu.component.html',
  styleUrls: ['./logedmenu.component.css']
})
export class LogedmenuComponent implements OnInit {

  constructor(private basews:BaseServiceService) { }
  user:any={};
  ngOnInit(): void {
    jsfix(); 
    this.user = this.basews.getActiveUser(); 
    console.log("dans menu parent "+window.localStorage.getItem("userToken"));
    if(window.localStorage && !localStorage.getItem("userToken") ){
       window.location.href ="/login";
    }
  }

}
