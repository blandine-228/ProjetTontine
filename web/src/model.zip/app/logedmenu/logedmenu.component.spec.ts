import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LogedmenuComponent } from './logedmenu.component';

describe('LogedmenuComponent', () => {
  let component: LogedmenuComponent;
  let fixture: ComponentFixture<LogedmenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LogedmenuComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LogedmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
